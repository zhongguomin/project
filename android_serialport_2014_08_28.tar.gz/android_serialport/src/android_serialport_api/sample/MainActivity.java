package android_serialport_api.sample;

import java.io.IOException;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends SerialPortActivity {
	
	EditText mReception;

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        mReception = (EditText) findViewById(R.id.EditTextReception);

        final Button buttonSetup = (Button)findViewById(R.id.ButtonSetup);
        buttonSetup.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				startActivity(new Intent(MainActivity.this, SerialPortPreferences.class));
			}
		});

        final Button buttonConsole = (Button)findViewById(R.id.sendBtn);
        buttonConsole.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				String testMsg = "hello, serial port is ok";
				try {
					mOutputStream.write(testMsg.getBytes());
					mOutputStream.write('\n');
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		});

    }

	@Override
	protected void onDataReceived(final byte[] buffer, final int size) {
		// TODO Auto-generated method stub
		runOnUiThread(new Runnable() {
			public void run() {
				if (mReception != null) {
					mReception.append(new String(buffer, 0, size));
				}
			}
		});
	}
	
}
